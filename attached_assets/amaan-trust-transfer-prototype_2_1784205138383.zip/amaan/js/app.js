/* ======================================================
   منطق التطبيق — تنقل بين الشاشات + محاكاة العمليات
   جميع البيانات وهمية، لا يوجد اتصال بأي خادم بنكي حقيقي
   ====================================================== */

(function () {
  "use strict";

  const screens = document.querySelectorAll(".screen");
  const bottomNav = document.getElementById("bottomNav");
  const TAB_SCREENS = ["home", "send-recipients", "history", "notifications", "settings"];
  const NO_BACK_SCREENS = ["splash", "login", "home"];

  let state = {
    selectedScenario: "high",
    currentTrust: null,
    recipient: { name: "خالد المطيري", amount: "3,200.00", bank: "مصرف الإنماء" },
    waitTimer: null,
    waitSeconds: 120,
    waitTotal: 120,
    history: JSON.parse(JSON.stringify(APP_DATA.history)),
    stack: []
  };

  /* ---------- تنقّل الشاشات ---------- */
  function showScreen(name, opts) {
    opts = opts || {};
    screens.forEach((s) => s.classList.toggle("active", s.dataset.screen === name));
    bottomNav.classList.toggle("visible", TAB_SCREENS.includes(name));
    bottomNav.querySelectorAll(".bn-item").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.nav === name);
    });
    if (!opts.silent) {
      state.stack.push(name);
    }
    document.getElementById("deviceScreen").scrollTop = 0;
    if (name === "trust-score") runTrustScoreScreen();
    if (name === "analysis") runAnalysisScreen();
    if (name === "waiting-approval") startWaitingCountdown();
    if (name === "home") renderHome();
    if (name === "history") renderHistory("all");
    if (name === "notifications") renderNotifications();
    if (name === "send-recipients") renderRecipients();
  }

  document.querySelectorAll("[data-nav]").forEach((el) => {
    el.addEventListener("click", () => showScreen(el.dataset.nav));
  });

  document.querySelectorAll("[data-back]").forEach((el) => {
    el.addEventListener("click", () => {
      state.stack.pop();
      const prev = state.stack.length ? state.stack.pop() : "home";
      showScreen(prev || "home");
    });
  });

  /* ---------- شاشة البداية ---------- */
  setTimeout(() => showScreen("login", { silent: true }), 2200);

  /* ---------- تسجيل الدخول ---------- */
  document.getElementById("loginForm").addEventListener("submit", (e) => {
    e.preventDefault();
    showScreen("home", { silent: true });
    state.stack = ["home"];
  });
  document.getElementById("biometricBtn").addEventListener("click", () => {
    showScreen("home", { silent: true });
    state.stack = ["home"];
  });

  /* ---------- الساعة الوهمية ---------- */
  function tickClock() {
    const el = document.getElementById("clock");
    const d = new Date();
    let h = d.getHours() % 12; if (h === 0) h = 12;
    const m = d.getMinutes().toString().padStart(2, "0");
    el.textContent = `${h}:${m}`;
  }
  tickClock();
  setInterval(tickClock, 30000);

  /* ---------- تنسيق الأرقام ---------- */
  function fmt(n) {
    return Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  /* ---------- الرئيسية ---------- */
  function renderHome() {
    document.getElementById("balanceValue").textContent = fmt(APP_DATA.user.balance);

    const txList = document.getElementById("homeTxList");
    txList.innerHTML = state.history.slice(0, 4).map(txRow).join("");

    const summary = document.getElementById("homeTrustSummary");
    const levels = [
      { label: "مرتفعة", pct: 91, cls: "high" },
      { label: "متوسطة", pct: 68, cls: "mid" },
      { label: "منخفضة", pct: 34, cls: "low" }
    ];
    summary.innerHTML = levels.map(l => `
      <div class="mini-trust">
        <div class="mini-trust-bar"><span class="mini-trust-fill fill-${l.cls}" style="width:${l.pct}%"></span></div>
        <div class="mini-trust-foot"><span>${l.label}</span><strong>${l.pct}</strong></div>
      </div>`).join("");
  }

  function statusChip(status) {
    if (status === "done") return '<span class="chip chip-green">مكتملة</span>';
    if (status === "pending") return '<span class="chip chip-amber">قيد الموافقة</span>';
    return '<span class="chip chip-red">ملغاة</span>';
  }

  function txRow(tx) {
    return `
    <div class="tx-row">
      <div class="tx-avatar">${tx.name.trim().slice(0, 2)}</div>
      <div class="tx-mid">
        <strong>${tx.name}</strong>
        <span>${tx.date} · ${tx.ref}</span>
      </div>
      <div class="tx-end">
        <strong>${fmt(tx.amount)} ر.س</strong>
        ${statusChip(tx.status)}
      </div>
    </div>`;
  }

  /* ---------- اختيار المستلم ---------- */
  function renderRecipients() {
    const t = document.getElementById("trustedRecipients");
    const o = document.getElementById("otherRecipients");
    t.innerHTML = APP_DATA.trustedRecipients.map(recipientRow).join("");
    o.innerHTML = APP_DATA.otherRecipients.map(recipientRow).join("");
    document.querySelectorAll(".recipient-row").forEach((row) => {
      row.addEventListener("click", () => {
        const idx = row.dataset.idx;
        const list = row.dataset.list === "trusted" ? APP_DATA.trustedRecipients : APP_DATA.otherRecipients;
        const r = list[idx];
        state.recipient = { name: r.name, amount: "1,000.00", bank: r.bank };
        document.getElementById("rName").value = r.name;
        document.getElementById("rIban").value = r.iban;
        document.getElementById("rAmount").value = "1,000.00";
        const seg = r.score >= 85 ? "high" : r.score >= 60 ? "mid" : "low";
        selectScenario(seg);
        showScreen("recipient-form");
      });
    });
  }

  function recipientRow(r, idx, arr) {
    const listKey = arr === APP_DATA.trustedRecipients ? "trusted" : "other";
    const trustCls = r.score >= 85 ? "high" : r.score >= 60 ? "mid" : "low";
    return `
    <div class="recipient-row" data-idx="${idx}" data-list="${listKey}">
      <div class="tx-avatar">${r.avatar}</div>
      <div class="tx-mid">
        <strong>${r.name}</strong>
        <span>${r.bank}</span>
      </div>
      <div class="recipient-score score-${trustCls}">${r.score}</div>
    </div>`;
  }

  /* ---------- سيناريو العرض التوضيحي ---------- */
  const scenarioSeg = document.getElementById("scenarioSeg");
  scenarioSeg.addEventListener("click", (e) => {
    const btn = e.target.closest(".seg-btn");
    if (!btn) return;
    selectScenario(btn.dataset.scenario);
  });
  function selectScenario(key) {
    state.selectedScenario = key;
    scenarioSeg.querySelectorAll(".seg-btn").forEach((b) =>
      b.classList.toggle("active", b.dataset.scenario === key)
    );
  }

  /* ---------- نموذج بيانات المستلم ---------- */
  document.getElementById("recipientForm").addEventListener("submit", (e) => {
    e.preventDefault();
    state.recipient = {
      name: document.getElementById("rName").value || "مستلم جديد",
      amount: document.getElementById("rAmount").value || "0.00",
      bank: document.getElementById("rBank").value
    };
    showScreen("analysis");
  });

  /* ---------- شاشة التحليل ---------- */
  function runAnalysisScreen() {
    const items = document.querySelectorAll("#analysisSteps li");
    items.forEach((li) => li.classList.remove("done", "active"));
    let i = 0;
    function stepNext() {
      if (i > 0) items[i - 1].classList.add("done");
      if (i >= items.length) {
        setTimeout(() => showScreen("trust-score"), 450);
        return;
      }
      items[i].classList.add("active");
      i++;
      setTimeout(stepNext, 620);
    }
    stepNext();
  }

  /* ---------- شاشة مؤشر الثقة ---------- */
  const CIRC = 2 * Math.PI * 92;
  const ICONS = {
    clock: '<path d="M12 7v5l3 3"/><circle cx="12" cy="12" r="9"/>',
    history: '<path d="M3 3v5h5"/><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"/>',
    pulse: '<path d="M3 12h4l2-7 4 14 2-7h6"/>',
    match: '<path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/>',
    flag: '<path d="M5 3v18"/><path d="M5 4h11l-2 4 2 4H5"/>'
  };

  function runTrustScoreScreen() {
    const sc = APP_DATA.scenarios[state.selectedScenario];
    state.currentTrust = sc;

    const dial = document.getElementById("dialProgress");
    const dialNumber = document.getElementById("dialNumber");
    const dialLabel = document.getElementById("dialLabel");
    dial.setAttribute("stroke-dasharray", `${CIRC} ${CIRC}`);
    dial.setAttribute("stroke-dashoffset", `${CIRC}`);
    dial.classList.remove("trust-low", "trust-mid", "trust-high");
    dialNumber.textContent = "0";
    dialLabel.textContent = "جارٍ الحساب";

    document.getElementById("factorList").innerHTML = "";
    document.getElementById("trustBanner").className = "trust-banner";
    document.getElementById("trustActionBtn").textContent = "متابعة";

    setTimeout(() => {
      const offset = CIRC - (sc.score / 100) * CIRC;
      dial.style.transition = "stroke-dashoffset 1.1s cubic-bezier(.22,.9,.3,1)";
      dial.setAttribute("stroke-dashoffset", `${offset}`);
      dial.classList.add(`trust-${sc.levelKey}`);
      animateCount(dialNumber, sc.score, 1100);
      dialLabel.textContent = `ثقة ${sc.level}`;

      const banner = document.getElementById("trustBanner");
      banner.classList.add(`banner-${sc.levelKey}`);
      document.getElementById("trustBannerText").textContent = sc.summary;

      document.getElementById("factorList").innerHTML = sc.factors.map((f) => `
        <div class="factor-row">
          <span class="factor-ic"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">${ICONS[f.icon]}</svg></span>
          <div class="factor-mid">
            <strong>${f.label}</strong>
            <span>${f.detail}</span>
            <div class="factor-bar"><span style="width:${f.value}%" class="fill-${sc.levelKey}"></span></div>
          </div>
          <strong class="factor-val">${f.value}</strong>
        </div>`).join("");

      document.getElementById("scoreTxSummary").innerHTML = `
        <div class="wait-card-row"><span>المستلم</span><strong>${state.recipient.name}</strong></div>
        <div class="wait-card-row"><span>المبلغ</span><strong>${state.recipient.amount} ر.س</strong></div>
        <div class="wait-card-row"><span>البنك</span><strong>${state.recipient.bank}</strong></div>`;

      document.getElementById("trustActionBtn").textContent = sc.requiresApproval
        ? "متابعة مع طلب موافقة المستلم"
        : "تأكيد الحوالة";
    }, 250);
  }

  function animateCount(el, target, duration) {
    const start = performance.now();
    function frame(now) {
      const p = Math.min(1, (now - start) / duration);
      el.textContent = Math.round(p * target);
      if (p < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  document.getElementById("trustActionBtn").addEventListener("click", () => {
    const sc = state.currentTrust;
    document.getElementById("waitRecipientName").textContent = state.recipient.name;
    document.getElementById("waitAmount").textContent = `${state.recipient.amount} ر.س`;
    document.getElementById("approveAmount").textContent = `${state.recipient.amount} ر.س`;
    if (sc.requiresApproval) {
      showScreen("waiting-approval");
    } else {
      finalizeTransfer("success");
    }
  });

  /* ---------- شاشة انتظار الموافقة ---------- */
  function startWaitingCountdown() {
    clearInterval(state.waitTimer);
    state.waitSeconds = 120;
    state.waitTotal = 120;
    updateWaitUI();
    state.waitTimer = setInterval(() => {
      state.waitSeconds--;
      updateWaitUI();
      if (state.waitSeconds <= 0) {
        clearInterval(state.waitTimer);
        finalizeTransfer("cancelled", "انتهت المهلة دون ورود موافقة من المستلم، فتم إلغاء العملية تلقائيًا حماية لحسابك.");
      }
    }, 1000);
  }
  function updateWaitUI() {
    const m = Math.floor(state.waitSeconds / 60).toString().padStart(2, "0");
    const s = (state.waitSeconds % 60).toString().padStart(2, "0");
    document.getElementById("waitTimer").textContent = `${m}:${s}`;
    const circ = 2 * Math.PI * 62;
    const prog = document.getElementById("waitProgress");
    prog.setAttribute("stroke-dasharray", `${circ} ${circ}`);
    const offset = circ * (1 - state.waitSeconds / state.waitTotal);
    prog.setAttribute("stroke-dashoffset", `${offset}`);
  }
  document.getElementById("cancelWaitBtn").addEventListener("click", () => {
    clearInterval(state.waitTimer);
    finalizeTransfer("cancelled", "قمت بإلغاء الحوالة يدويًا قبل ورود موافقة المستلم.");
  });

  /* ---------- شاشة معاينة قبول/رفض ---------- */
  document.getElementById("acceptBtn").addEventListener("click", () => {
    clearInterval(state.waitTimer);
    finalizeTransfer("success");
  });
  document.getElementById("rejectBtn").addEventListener("click", () => {
    clearInterval(state.waitTimer);
    finalizeTransfer("cancelled", "رفض المستلم استلام هذه الحوالة، فتم إلغاؤها فورًا لحمايتك.");
  });

  /* ---------- إنهاء العملية ---------- */
  function finalizeTransfer(result, reason) {
    const ref = "AM-" + Math.floor(40000 + Math.random() * 9000);
    state.history.unshift({
      name: state.recipient.name,
      amount: parseFloat((state.recipient.amount + "").replace(/,/g, "")) || 0,
      date: "الآن",
      status: result === "success" ? "done" : "cancelled",
      ref
    });
    if (result === "success") {
      document.getElementById("successName").textContent = state.recipient.name;
      document.getElementById("successAmount").textContent = `${state.recipient.amount} ر.س`;
      document.getElementById("successRef").textContent = ref;
      showScreen("success", { silent: true });
      state.stack = ["home", "success"];
    } else {
      document.getElementById("cancelName").textContent = state.recipient.name;
      document.getElementById("cancelAmount").textContent = `${state.recipient.amount} ر.س`;
      document.getElementById("cancelReason").textContent = reason || "تم إلغاء الحوالة.";
      showScreen("cancelled", { silent: true });
      state.stack = ["home", "cancelled"];
    }
  }

  /* ---------- سجل الحوالات ---------- */
  function renderHistory(filter) {
    const list = document.getElementById("historyList");
    const data = filter === "all" ? state.history : state.history.filter((t) => t.status === filter);
    list.innerHTML = data.length
      ? data.map(txRow).join("")
      : `<div class="empty-state">لا توجد عمليات ضمن هذا التصنيف حاليًا</div>`;
  }
  document.getElementById("historyFilter").addEventListener("click", (e) => {
    const btn = e.target.closest(".seg-btn");
    if (!btn) return;
    document.querySelectorAll("#historyFilter .seg-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    renderHistory(btn.dataset.filter);
  });

  /* ---------- الإشعارات ---------- */
  const NOTIF_ICON = {
    trust: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/>',
    success: '<path d="M20 6L9 17l-5-5"/>',
    pending: '<path d="M12 7v5l3 3"/><circle cx="12" cy="12" r="9"/>',
    cancel: '<path d="M18 6L6 18M6 6l12 12"/>',
    security: '<path d="M12 22s8-4.5 8-11V5l-8-3-8 3v6c0 6.5 8 11 8 11Z"/>'
  };
  function renderNotifications() {
    document.getElementById("notifList").innerHTML = APP_DATA.notifications.map((n) => `
      <div class="notif-row">
        <span class="notif-ic notif-${n.type}"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">${NOTIF_ICON[n.type]}</svg></span>
        <div class="notif-mid">
          <strong>${n.title}</strong>
          <span>${n.body}</span>
          <small>${n.time}</small>
        </div>
      </div>`).join("");
  }

  /* ---------- الإعدادات ---------- */
  document.getElementById("sensitivitySeg").addEventListener("click", (e) => {
    const btn = e.target.closest(".seg-btn");
    if (!btn) return;
    document.querySelectorAll("#sensitivitySeg .seg-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
  });

  /* ---------- الحالة الابتدائية ---------- */
  selectScenario("high");
})();
